<div>
<label><b>Name</b>:<?php echo $name; ?></label><br/><br/>
<label><b>Email</b>:<?php echo $email; ?></label><br/><br/>
<label><b>Phone</b>:<?php echo $phone; ?></label>
</div>