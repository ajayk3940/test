<div>
<label><b>Name</b>:<?php echo $name; ?></label><br/><br/>
<label><b>Email</b>:<?php echo $email; ?></label><br/><br/>
<label><b>Phone</b>:<?php echo $phone; ?></label><br/><br/>

 <!-- <button type="submit" name="dwnld" id="dwnld">Download</button>-->
 <a href="<?php echo base_url(); ?>welcome/save_download">Download<a>
</div>