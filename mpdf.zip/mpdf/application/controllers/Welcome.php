<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		if($this->input->post()){
			$this->form_validation->set_rules('username', 'Name', 'required|alpha');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('phone', 'Phone', 'required|numeric|min_length[9]|max_length[10]');
			if ($this->form_validation->run() == FALSE)
                {
					$this->session->set_flashdata('error', validation_errors());
                    $this->load->view('welcome_message');
                }
                else
                {
					$this->session->set_userdata(array(
						'name'  => $this->input->post('username'),
						'email' => $this->input->post('email'),
						'phone'  => $this->input->post('phone')
					));
					$data['name']=$this->input->post('username');
					$data['email']=$this->input->post('email');
					$data['phone']=$this->input->post('phone');
                    $this->load->view('formsuccess', $data);
                }
				
		} else {
		$this->load->view('welcome_message');
		}
	}
	 public function save_download()
  { 
		//load mPDF library
		$this->load->library('m_pdf');
		//load mPDF library


		//now pass the data//
		 $data['name']=$this->session->userdata('name');
		 $data['email']=$this->session->userdata('email');
		 $data['phone']=$this->session->userdata('phone');
		 //now pass the data //

		
		$html=$this->load->view('pdf_output',$data, true); //load the pdf_output.php by passing our data and get all data in $html varriable.
 	 
		//this the the PDF filename that user will get to download
		$pdfFilePath ="mypdfName-".time()."-download.pdf";

		
		//actually, you can pass mPDF parameter on this load() function
		$pdf = $this->m_pdf->load();
		//generate the PDF!
		$pdf->WriteHTML($html,2);
		//offer it to user via browser download! (The PDF won't be saved on your server HDD)
		$pdf->Output($pdfFilePath, "D");
		 
		 	
  }
}
